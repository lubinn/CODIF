//  config.c  mkv  21-jul-98

//  mkv 28-sep-98 inverted sense of mv xilinx reset


#include <config.h>
#include <dio.h>

#include <hc12.h>


void set_configuration(void)
{
  // setup strobes
  CSSTR1 = (0XFF - STR2M) | STR2V;              // set up cs2 e-clock stretch
  CSCTL1 = CSDHF;                               // CSD covers 0x0000 - 0x7FFF
  CSCTL0 = CSP1E | CSP0E | CSDE | CS2E;         // enable strobes

  // set port directions
  // default is input - set bits corresponding to outputs

  // set port j
  // PORTJ = 0;
  // DDRJ  = 0;

  // set port h
  // PORTH = 0;
  // DDRH  = 0;

  // set port t - dio i/o and control
#ifdef MKV_IO
  PORTT = DIO_XRESET;
  DDRT  = DIO_REQ2 | DIO_IN2 | DIO_XRESET;
#else
  PORTT = DIO_RSM;
  DDRT  = DIO_REQ2 | DIO_IN2 | DIO_RSM;
#endif

  // set port g - power board control
  PORTG = 0;
  DDRG  = PWR_28V | PWR_VD | PWR_MUX;

  // set port ad - power board a/d conversions
  ATDCTL2 = ADPU;
}

