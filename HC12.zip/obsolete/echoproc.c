//  echoproc.c  mkv  25-jul-98

#include "process.h"

const char * process_version = __FILE__ " " __DATE__ " " __TIME__ "\n";

void process(QUEUE * q_dst, QUEUE * q_src)
{
  if (! que_isempty(q_src))
  {
    que_put(q_dst, 1);
    que_put(q_dst, que_remove(q_src, 0));

    que_put_commit(q_dst);
  }
} 
