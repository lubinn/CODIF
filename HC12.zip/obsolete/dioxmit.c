//  dioxmit.c  mkv  21-jun-98

#include "config.h"
#include "dio.h"
#include "que.h"
#include "utl.h"

#include <hc12.h>
#include <stdio.h>





  

