//  input.c  mkv  25-jul-98

#include "input.h"

#include <hc12.h>
#include <stdio.h>

#include "utl.h"
#include "dio.h"
#include "que.h"


const char * input_version = __FILE__ " " __DATE__ " " __TIME__ "\n";

void input(QUEUE * q_dst)
{
  dio_read_request();
  if (dio_read_ready())
  {
    unsigned short timeout;
    unsigned short data = dio_read_word();

    que_insert(q_dst, data);
    dio_read_acknowledge();

    puts("\ni: "); putu(data, 16, 4);

    timeout = 0;
    while (--timeout && dio_read_ready())
    {
    }

    dio_read_request();

    timeout = 0;
    while (--timeout && ! dio_read_ready())
    {
    }
  }
} 
