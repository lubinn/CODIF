//  test1.c

#include "dio.h"
#include "config.h"

#include <stdio.h>
#include <hc12.h>


void main(void)
{
  set_configuration();

  {
    unsigned short old_port_t = PORTT;
    unsigned short new_port_t;
    unsigned short data;

    do    
    {
      printf( "port_t: %x  data: %x\n", old_port_t, data);

      do
      {
        new_port_t = PORTT;
      }
      while (new_port_t == old_port_t);

      data   = dio_read_word();  

      PORTT ^= DIO_REQ2;

      old_port_t = (PORTT ^= DIO_REQ2);
    }
    while (1);
  }

/*
  {
    unsigned short timeout = 20000;
    unsigned short timer   = 0;
    unsigned short data    = 0;

    dio_read_request();
    dio_write_acknowledge();

    while (1)
    {
      PORTT = 0xFF;
      PORTT = 0x00;

      data = dio_get();
      data = dio_put(data);

      printf("data: %x\n", data);
    }
  }
*/

/*
  {
    unsigned short new_dio_csr;
    unsigned short new_dio_dat;
    unsigned short old_dio_csr = DIO_CSR;
    unsigned short old_dio_dat = DIO_DAT;

    do    
    {
      printf( "dio csr: %x  dio dat: %x\n", old_dio_csr, old_dio_dat);

      do
      {
        PORTT = 0xFF;
        PORTT = 0x00;

        DIO_DAT = ++old_dio_dat;

        new_dio_csr = DIO_CSR;
        new_dio_dat = DIO_DAT;
      }
      while (new_dio_csr == old_dio_csr && new_dio_dat == old_dio_dat && new_dio_dat != 0);

      old_dio_csr = new_dio_csr;
      old_dio_dat = new_dio_dat;
    }
    while (1);
  }
*/
}  




  

