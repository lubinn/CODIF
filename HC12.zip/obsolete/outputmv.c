//  outputmv.c  mkv  25-jul-98

#include <output.h>
#include <utl.h>
#include <dio.h>

#include <hc12.h>
#include <stdio.h>


const char * output_version = __FILE__ " " __DATE__ " " __TIME__ "\n";

void output(QUEUE * q_src)
{
  dio_write_acknowledge();
  if (! que_isempty(q_src))
  {
    unsigned short n = que_get(q_src, 0);

    puts("\no: "); putu(n, 16, 4);

    while (n--)
    {
      unsigned short timeout;
      unsigned short data = que_get(q_src, 0);

      dio_write_word(data);

      dio_write_request();

//    putchar('<');

      timeout = 0;
      while (--timeout && dio_write_ready())
      {
      }

//    putchar('>');

      dio_write_acknowledge();

      putchar(' '); putu(data, 16, 4);

      timeout = 0;
      while (--timeout && ! dio_write_ready())
      {
      }
    }

    que_get_commit(q_src);
  }  
}  