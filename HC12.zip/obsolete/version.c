const char * version = "dioecho 0.0.1 " __DATE__ "\n";
