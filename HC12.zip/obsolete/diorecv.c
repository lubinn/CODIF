//  diorecv.c  mkv  21-jun-98

#include "dio.h"
#include "config.h"

#include <stdio.h>
#include <hc12.h>


void main(void)
{
  unsigned short data = 0;

  set_configuration();

  DDRT |= 0x80;

  dio_read_request();

  while (1)
  {
      PORTT |= 0x80;
      PORTT &= 0x7F;

      dio_get(10, & data);
  }
}  




  

