//  procxmit.c  mkv  25-jul-98

#include "process.h"

#include <stdio.h>

#include "utl.h"

const char * process_version = __FILE__ " " __DATE__ " " __TIME__ "\n";

static unsigned short packet[10] = { 7, 0, 5, 0x0100, 0, 0, 0, 0 };

void process(QUEUE * q_dst, QUEUE * q_src)
{
  if (! que_isempty(q_src))
  {
    unsigned short data = que_remove(q_src, 0);
    unsigned short i;

    packet[4] += 1;
    packet[5]  = data;
    packet[7]  = 0;

    
    for (i = 1 ; i < 7 ; ++i )
    {
      add_to_checksum(& packet[7], packet[i]);
    }
  
    que_insert_array(q_dst, packet);

    puts("\np: "); putu(data, 16, 4);
  }
} 
