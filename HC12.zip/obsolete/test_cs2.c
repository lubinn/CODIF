//  test1.c

#include <stdio.h>
#include <hc12.h>

//  port t bit definitions
#define ACK2  (0x01)  // bit 0 - an input
//efine       (0x02)  // bit 1 
#define BUSY  (0x04)  // bit 2 - an input
#define REQ2  (0x08)  // bit 3 - an output
//efine       (0x10)  // bit 4
#define IN2   (0x20)  // bit 5 - an output
#define OUT2  (0x40)  // bit 6 - an input
//efine       (0x80)  // bit 7

//  input data definitions
#define MSB   PORTH   // most  significant byte
#define LSB   PORTJ   // least significant byte

//  xilinx base
#define XBASE (*(unsigned short *)(0xB80))
#define CS2E  (0x04)
#define STR2M (0x30)
#define STR2V (0x30)

void set_configuration(void)
{

  // set port directions
  // default is input - set bits corresponding to outputs

  // set direction of port t
  PORTT = 0xff;
  DDRT  = REQ2 | IN2;

  // set direction of port j
  PORTJ = 0;

  // set direction of port h
  PORTH = 0;

  // setup cs2
  CSSTR1 = (CSSTR1 & ~ STR2M) | STR2V;    // set up cs2 e-clock stretch
  CSCTL0 |= CS2E;                         // enable cs2
}


//  dio single bit i/o
#define dio_bit_set()           (PORTT |=   IN2)
#define dio_bit_reset()         (PORTT &= ~ IN2)
#define dio_bit_test()          (PORT  &    OUT2)


//  dio word input
#define dio_data_request()      (PORTT |=   REQ2)
#define dio_data_acknowledge()  (PORTT &= ~ REQ2)
#define dio_data_ready()        (PORTT &    ACK2)
#define dio_data_get()          ((((unsigned short) MSB) << 8) + LSB)


unsigned short dio_data_read(void)
{
  unsigned short temp;

  dio_data_request();

  while (! dio_data_ready())
  {
  }

  temp = dio_data_get();
  
  dio_data_acknowledge();
    
  while (dio_data_ready())
  {
  }

  return temp;
}


void main(void)
{
  set_configuration();

/*
  {


    unsigned short new_port_t;
    unsigned short new_data;
    unsigned short old_port_t = PORTT;
    unsigned short old_data   = dio_data_get();

    do    
    {
      printf( "port_t: %x  data: %x\n", old_port_t, old_data);

      do
      {
        new_port_t = PORTT;
        new_data   = dio_data_get();
      }
      while (new_port_t == old_port_t && new_data == old_data);

      old_port_t = new_port_t;
      old_data   = new_data;  
    }
    while (1);
  }
*/

  while (1)
  {
    XBASE = XBASE + 1;
  }
}  




  

