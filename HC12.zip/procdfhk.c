//  procdfhk.c  mkv  17-aug-98

//  mkv  22-aug-98  rewrote for tf interface


#include <process.h>


int process_cdf_housekeeping(unsigned short * packet)
{
  int reply = 0;

  if ((packet[PKT_OPID] & ID_HKP_MASK) != ID_HKP_BASE)
    return 0;

  {
    unsigned short wcnt  = packet[PKT_WCNT];

    switch (packet[PKT_OPID] & ID_HKP_SUBOP)
    {
      case 0: // read all housekeeping values
        switch (wcnt)
        {
          case 2:
          {
            unsigned char  * ptr = (unsigned char *) & packet[PKT_DAT0];
            unsigned short   n;

            // fill the packet with all 8 values, two (byte) values per word
            packet[PKT_WCNT] = 6;

            for (n = 0 ; n < 8 ; ++n)
            {
              unsigned short timeout = 5;
              unsigned short temp;

              // set the mux address
              set_cdf_reg(0, CDF_REG_HKP_MUX_ADDR, n);

              // start the conversion
              set_cdf_reg(0, CDF_REG_HKP_ADC_DATA, 0);

              // wait for it to finish
              do
                get_cdf_reg(0, CDF_REG_HKP_MUX_ADDR, & temp);
              while ((temp & 0x40) && --timeout);

              // get the data            
              get_cdf_reg(0, CDF_REG_HKP_ADC_DATA, & temp);

              // put it in the packet
              * ptr++ = (unsigned char) temp;
            }
            
            reply = 1;
          }
        }
    }
  }

  if (! reply)
    packet[PKT_WCNT] = 0;    

  return 1;
}  
