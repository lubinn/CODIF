//  procdfra.c  mkv  17-aug-98

//  mkv  23-aug-98  rewrote for tf interface
//  mkv  31-aug-98  rewrote for mv and tf interfaces
//  mkv  13-sep-98  modified for all rates packets
//  mkv  30-sep-98  made LAST_RATE 18, fixed base_reg bug

#include <process.h>

#define LAST_RATE (18)


int process_cdf_rates(unsigned short * packet)
{
  if ((packet[PKT_OPID] & ID_RAT_MASK) != ID_RAT_BASE)
    return 0;

  if (packet[PKT_WCNT] == 2)
  {
    unsigned short   base_reg = (packet[PKT_OPID] & 0x0008 ? CDF_REG_HS_RATES_LO : CDF_REG_LS_RATES_LO);
    unsigned short   begin    = (packet[PKT_OPID] & 0x0007) << 2;
    unsigned short   end      = begin + 3;
    unsigned short * ptr      = & packet[PKT_DAT0];

    // don't send unused rates
    if (end > LAST_RATE)
      end = LAST_RATE;

    // check for all rates packet
    if (begin > LAST_RATE)
      begin = 0;

    packet[PKT_WCNT] += end - begin + 1;

    // set the initial address
    set_cdf_reg(0, base_reg + 3, begin);

    // read the selected rates
    while (begin++ <= end)
      get_cdf_reg(0, base_reg, ptr++);
  }
  else
    packet[PKT_WCNT] = 0;    

  return 1;
}  
