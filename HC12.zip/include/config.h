//  config.h  mkv  21-jul-98

#ifndef CONFIG_H
#define CONFIG_H

void set_configuration(void);

#endif
