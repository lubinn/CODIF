//  input.h  mkv  25-jul-98

//  21-sep-98  mkv  added display_input;


#ifndef INPUT_H
#define INPUT_H

#include "que.h"

extern const char * input_version;

extern int display_input;

extern void (*input)(QUEUE *);

#endif
