//  process.h  mkv  25-jul-98

//  mkv  02-oct-98  added process_cdf_poll

#ifndef PROCESS_H
#define PROCESS_H

#include <stdio.h>
#include <hc12.h>

#include <utl.h>
#include <dio.h>
#include <ids.h>
#include <que.h>


#define PKT_LENG    (0)
#define PKT_ZERO    (1)
#define PKT_WCNT    (2)
#define PKT_OPID    (3)
#define PKT_SEQN    (4)
#define PKT_DATA    (5)
#define PKT_DAT0    (5)
#define PKT_DAT1    (6)
#define PKT_DAT2    (7)
#define PKT_DAT3    (8)

typedef int processor(unsigned short * packet);

extern const char * process_version;

void process(QUEUE * dst, QUEUE * src);

int process_pwr_general(unsigned short * packet);
int process_cdf_general(unsigned short * packet);
int process_cdf_housekeeping(unsigned short * packet);
int process_cdf_rates(unsigned short * packet);
int process_cdf_immediate(unsigned short * packet);
int process_cdf_poll(unsigned short * packet);

void cdf_reg_write(unsigned short reg);
void cdf_reg_read(unsigned short reg);

#endif
