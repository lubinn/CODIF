//  dio.h  mkv  21-jul-98

//  mkv 30-jul-98 added codif defines
//  mkv 19-aug-98 reorganized to include conditionalized tf xilinx interface
//  mkv 28-sep-98 inverted sense of mv xilinx reset
//  mkv 07-oct-98 added FFO_CTL_RESET

#ifndef DIO_H
#define DIO_H

#include <hc12.h>


// additional standard hc12 defines beyond hc12.h -----------------------------------------

// power board control and a/d conversion
#define ADPU                    (0x80)  // in ATDCTL2 -- powerup a/d subsystem
#define AFFC                    (0x40)  // in ATDCTL2 -- fast flag clear

#define S8CM                    (0x40)  // in ATDCTL5 -- select 8 channel mode
#define SCAN                    (0x20)  // in ATDCTL5 -- enable continuous scan
#define MULT                    (0x10)  // in ATDCTL5 -- enable multichannel conversion
#define CD                      (0x08)  // in ATDCTL5 -- channel select field
#define CC                      (0x04)  // in ATDCTL5 -- channel select field
#define CB                      (0x02)  // in ATDCTL5 -- channel select field
#define CA                      (0x01)  // in ATDCTL5 -- channel select field

#define SCF                     (0x8000)// in ATDSTAT -- sequence complete flag

#define PWR_MUX                 (0x0F)  // in PORTG   -- power board selection mux field
#define PWR_28V                 (0x20)  // in PORTG   -- power board +28V on/off control
#define PWR_VD                  (0x10)  // in PORTG   -- power board device voltage on/off control

#define PWR_HK0                 (0x00)  // in PORTAD  -- power board housekeeping channel
#define PWR_T1                  (0x01)  // in PORTAD  -- power board temperature 1 channel
#define PWR_T2                  (0x02)  // in PORTAD  -- power board temperature 2 channel
#define PWR_T3                  (0x03)  // in PORTAD  -- power board temperature 3 channel
#define PWR_HK0_B               (0x01)  // in PORTAD  -- power board housekeeping bit
#define PWR_T1_B                (0x02)  // in PORTAD  -- power board temperature 1 bit
#define PWR_T2_B                (0x04)  // in PORTAD  -- power board temperature 2 bit
#define PWR_T3_B                (0x08)  // in PORTAD  -- power board temperature 3 bit

// external bus signals
#define RDWE                    (0x04)  // in PEAR    -- external read/write enable
#define LSTRE                   (0x08)  // in PEAR    -- external low strobe enable
#define ARSIE                   (0x80)  // in PEAR    -- external alternate reset enable

//  chip select CS2
#define CS0E                    (0x01)  // in CSCTL0  -- CS0  enable
#define CS1E                    (0x02)  // in CSCTL0  -- CS1  enable
#define CS2E                    (0x04)  // in CSCTL0  -- CS2  enable
#define CS3E                    (0x08)  // in CSCTL0  -- CS3  enable
#define CSDE                    (0x10)  // in CSCTL0  -- CSD  enable
#define CSP0E                   (0x20)  // in CSCTL0  -- CSP0 enable
#define CSP1E                   (0x30)  // in CSCTL0  -- CSP1 enable

#define CSDHF                   (0x10)  // in CSCTL1  -- CSD covers 0x0000 - 0x7FFF

#define STR2M                   (0x30)  // in CSSTR1  -- ECLK stretch mask
#define STR2V                   (0x30)  // in CSSTR1  -- ECLK stretch value


// gse specific defines common to mkv and tf interfaces -----------------------------------

// codif register defines
#define CDF_REG_LS_RATES_LO     (0x00)  // RO
#define CDF_REG_LS_RATES_HI     (0x01)  // RO
#define CDF_REG_LS_ASIC_SAMP    (0x02)  // RW
#define CDF_REG_LS_ASIC_MODE    (0x03)  // RW
#define CDF_REG_HS_RATES_LO     (0x04)  // RO
#define CDF_REG_HS_RATES_HI     (0x05)  // RO
#define CDF_REG_HS_ASIC_SAMP    (0x06)  // RW
#define CDF_REG_HS_ASIC_MODE    (0x07)  // RW
#define CDF_REG_LS_STIMULATION  (0x08)  // RW
#define CDF_REG_LS_CONTROL      (0x09)  // RW
#define CDF_REG_LS_PHA_TOF      (0x0A)  // RO
#define CDF_REG_LS_PHA_POSITION (0x0B)  // RO
#define CDF_REG_HS_STIMULATION  (0x0C)  // RW
#define CDF_REG_HS_CONTROL      (0x0D)  // RW
#define CDF_REG_HS_PHA_TOF      (0x0E)  // RO
#define CDF_REG_HS_PHA_POSITION (0x0F)  // RO
#define CDF_REG_LS_EVENT_POLL   (0x10)  // RW
#define CDF_REG_LS_DIAGNOSTIC_1 (0x11)  // RO
#define CDF_REG_LS_DIAGNOSTIC_2 (0x12)  // RO
#define CDF_REG_LS_DIAGNOSTIC_3 (0x13)  // RO
#define CDF_REG_HS_EVENT_POLL   (0x14)  // RW
#define CDF_REG_HS_DIAGNOSTIC_1 (0x15)  // RO
#define CDF_REG_HS_DIAGNOSTIC_2 (0x16)  // RO
#define CDF_REG_HS_DIAGNOSTIC_3 (0x17)  // RO
#define CDF_REG_HIGH_VOLTAGE    (0x18)  // RW
#define CDF_REG_IMMED_POLL_CODE (0x19)  // RW
#define CDF_REG_DIAGNOSTIC_4    (0x1A)  // RO
#define CDF_REG_HKP_MUX_ADDR    (0x1B)  // RW
#define CDF_REG_HKP_ADC_DATA    (0x1C)  // RW
#define CDF_REG_DAC_SETTING_MCP (0x1D)  // WO
#define CDF_REG_DAC_SETTING_ACC (0x1E)  // WO
#define CDF_REG_UNUSED          (0x1F)       

// instrument housekeeping
#define CDF_HKP_P5V             (0X00)
#define CDF_HKP_P12V            (0X01)
#define CDF_HKP_M5V             (0X02)
#define CDF_HKP_PACV            (0X03)
#define CDF_HKP_PACI            (0X04)
#define CDF_HKP_MCPV            (0X05)
#define CDF_HKP_MCPI            (0X06)
#define CDF_HKP_T1              (0X07)

//  dio data input registers
#define DIO_MSB                 PORTH   // most  significant byte
#define DIO_LSB                 PORTJ   // least significant byte

//  dio input control 
#define DIO_ACK2                (0x01)  // in PORTT   - an input
#define DIO_RSM                 (0x02)  // in PORTT   - an output - reset state machine
#define DIO_BUSY                (0x04)  // in PORTT   - an input  - xilinx busy
#define DIO_REQ2                (0x08)  // in PORTT   - an output
#define DIO_IN2                 (0x20)  // in PORTT   - an output
#define DIO_OUT2                (0x40)  // in PORTT   - an input
//efine DIO_                    (0x80)  // in PORTT   -  

//  dio single bit i/o
#define dio_write_set()         (PORTT |=   DIO_IN2 )
#define dio_write_reset()       (PORTT &= ~ DIO_IN2 )
#define dio_read_test()         (PORT  &    DIO_OUT2)

//  dio word input
#define dio_read_request()      (PORTT |=   DIO_REQ2)
#define dio_read_acknowledge()  (PORTT &= ~ DIO_REQ2)
#define dio_read_ready()        (PORTT &    DIO_ACK2)
#define dio_read_word()         ((((unsigned short) DIO_MSB) << 8) + DIO_LSB)


unsigned short dio_get(unsigned short timeout, unsigned short * data);


//  xilinx interface defines - two versions, one per mkv, one per tf ----------------------
#define X_BASE                  (0x380) //  xilinx base

// codif i/f bits in commands
#define CDF_BIT_CNTSMP          (0x0100)
#define CDF_BIT_HFLG            (0x0080) 
#define CDF_BIT_LFLG            (0x0040) 
#define CDF_BIT_LUMON           (0x0020) 
#define CDF_BIT_STANDBY         (0x0010) 
#define CDF_BIT_RESET           (0x0008) 
#define CDF_BIT_PWCTLH          (0x0004) 
#define CDF_BIT_PWCTLL          (0x0002) 
#define CDF_BIT_PHAFLG          (0x0001) 

#ifdef  MKV_IO  //  i/o per mkv xilinx ----------------------------------------------------

//  word output to dio 
#define DIO_CSR                 (*(unsigned short *) (X_BASE +  0))
#define DIO_STS                 (*(unsigned char  *) (X_BASE +  0))
#define DIO_CTL                 (*(unsigned char  *) (X_BASE +  1))
#define DIO_DAT                 (*(unsigned short *) (X_BASE +  2))

#define DIO_ACK1                (0x01)  // in DIO_STS
#define DIO_IN1                 (0x02)  // in DIO_STS
#define DIO_REQ1                (0x01)  // in DIO_CTL
#define DIO_OUT1                (0x02)  // in DIO_CTL

#define dio_write_request()     (DIO_CTL |=   DIO_REQ1)
#define dio_write_acknowledge() (DIO_CTL &= ~ DIO_REQ1)
#define dio_write_ready()       (DIO_STS &    DIO_ACK1)
#define dio_write_word(w)       (DIO_DAT =    w       )


//  register and bit i/f to codif
#define CDF_CSR                 (*(unsigned short *) (X_BASE +  4))
#define CDF_STS                 (*(unsigned char  *) (X_BASE +  4))
#define CDF_CTL                 (*(unsigned char  *) (X_BASE +  5))
#define CDF_DAT                 (*(unsigned short *) (X_BASE +  6))

#define CDF_STS_RESET           (0x01)  // in CDF_STS
#define CDF_STS_CNTSMP          (0x02)  // in CDF_STS
#define CDF_STS_WRITE           (0x04)  // in CDF_STS
#define CDF_STS_READ            (0x08)  // in CDF_STS
#define CDF_STS_LUMON           (0x10)  // in CDF_STS
#define CDF_STS_STANDBY         (0x20)  // in CDF_STS
#define CDF_STS_LFLG            (0x40)  // in CDF_STS
#define CDF_STS_HFLG            (0x80)  // in CDF_STS

#define CDF_CTL_REG_MASK        (0x1F)  // in CDF_CTL
#define CDF_CTL_PHAFLG          (0x20)  // in CDF_CTL
#define CDF_CTL_PWCTLL          (0x40)  // in CDF_CTL
#define CDF_CTL_PWCTLH          (0x80)  // in CDF_CTL

#define CDF_CSR_REG_MASK        (0x001F)// in CDF_CSR
#define CDF_CSR_PHAFLG          (0x0020)// in CDF_CSR 
#define CDF_CSR_PWCTLL          (0x0040)// in CDF_CSR 
#define CDF_CSR_PWCTLH          (0x0080)// in CDF_CSR 
#define CDF_CSR_RESET           (0x0100)// in CDF_CSR 
#define CDF_CSR_CNTSMP          (0x0200)// in CDF_CSR 
#define CDF_CSR_WRITE           (0x0400)// in CDF_CSR 
#define CDF_CSR_READ            (0x0800)// in CDF_CSR 
#define CDF_CSR_LUMON           (0x1000)// in CDF_CSR 
#define CDF_CSR_STANDBY         (0x2000)// in CDF_CSR 
#define CDF_CSR_LFLG            (0x4000)// in CDF_CSR 
#define CDF_CSR_HFLG            (0x8000)// in CDF_CSR 


//  read and count access to fifo
#define FFO_CSR                 (*(unsigned short *) (X_BASE +  8))
#define FFO_STS                 (*(unsigned char  *) (X_BASE +  8))
#define FFO_CTL                 (*(unsigned char  *) (X_BASE +  9))
#define FFO_DAT                 (*(unsigned short *) (X_BASE + 10))
#define FFO_CNT                 (*(unsigned short *) (X_BASE + 12))
#define FFO_MIS                 (*(unsigned short *) (X_BASE + 14))

#define FFO_STS_EMPTY			      (0x03)  // in FFO_STS
#define FFO_STS_HALF_FULL		    (0x0C)  // in FFO_STS
#define FFO_STS_FULL			      (0x30)  // in FFO_STS
#define FFO_CTL_READ			      (0x80)  // in FFO_CTL
#define FFO_CTL_RESET           (0x03)  // in FFO_CTL

#define DIO_XRESET              (0x04)  // in PORTT   - an output  - xilinx reset
#define dio_xreset()            (PORTT &= ~ DIO_XRESET , PORTT |= DIO_XRESET)

unsigned short dio_put(unsigned short timeout, unsigned short data);

#else  // i/o per tf xilinx ---------------------------------------------------------------

#define DIO_CSR                 (*(unsigned short *) (X_BASE +  0))
#define DIO_STS                 (*(unsigned char  *) (X_BASE +  0))
#define DIO_CTL                 (*(unsigned char  *) (X_BASE +  1))

#define DIO_GO                  (0x80)  // in DIO_STS

#define DIO_PKT_ZERO            (*(unsigned short *) (X_BASE +  2))
#define DIO_PKT_WCNT            (*(unsigned short *) (X_BASE +  4))
#define DIO_PKT_OPID            (*(unsigned short *) (X_BASE +  6))
#define DIO_PKT_SEQN            (*(unsigned short *) (X_BASE +  8))
#define DIO_PKT_DATA            (*(unsigned short *) (X_BASE + 10))
#define DIO_PKT_DAT0            (*(unsigned short *) (X_BASE + 10))
#define DIO_PKT_DAT1            (*(unsigned short *) (X_BASE + 12))
#define DIO_PKT_DAT2            (*(unsigned short *) (X_BASE + 14))
#define DIO_PKT_DAT3            (*(unsigned short *) (X_BASE + 16))
//efine DIO_PKT_CSUM            (*(unsigned short *) (X_BASE + 18))
//efine DIO_XXX_WCNT            (*(unsigned short *) (X_BASE + 20))
//efine DIO_FFO_LOST            (*(unsigned short *) (X_BASE + 22))
//efine DIO_FFO_WCNT            (*(unsigned short *) (X_BASE + 24))
//efine DIO_FFO_DATA            (*(unsigned short *) (X_BASE + 26))
//efine DIO_CDF_DATA            (*(unsigned short *) (X_BASE + 28))


// opid defines
#define DIO_OP_GET              (0x0000)
#define DIO_OP_SEND             (0x0000)
#define DIO_OP_REPLY            (0x4000)
#define DIO_OP_SET              (0x8000)
//efine DIO_OP_                 (0xC000)

#define DIO_DEV_PKT             (0x0100)  // go - send specified packet
#define DIO_DEV_CDF_REG         (0x0200)  // gs - get/set DIO_PKT_DATA from/to codif register
#define DIO_DEV_FFO_DATA        (0x0300)  // go - send fifo data
#define DIO_DEV_HC12            (0x0400)  //    - no op
#define DIO_DEV_DIO32           (0x0500)  //    - no op
#define DIO_DEV_CDF_CNTSMP      (0x0600)  // gs - generate cntsmp pulse
#define DIO_DEV_CDF_BITS_1      (0x0700)  // gs - get/set DIO_PKT_DATA from/to phaflg,pwctlh,pwctll,resetn
#define DIO_DEV_CDF_BITS_2      (0x0800)  // go - get     DIO_PKT_DATA from    latchup,hflg,lflg 
#define DIO_DEV_FFO_DATA_CNT    (0x0900)  // go - get     DIO_PKT_DATA from    fifo current data count 
#define DIO_DEV_FFO_LOST_CNT    (0x0A00)  // go - get     DIO_PKT_DATA from    fifo lost    data count 
#define DIO_DEV_FFO_RESET       (0x0B00)  // gs - reset fifo counters and data

#define DIO_BIT1_STANDBY        (0x0010) 
#define DIO_BIT1_RESETN         (0x0008) 
#define DIO_BIT1_PWCTLH         (0x0004) 
#define DIO_BIT1_PWCTLL         (0x0002) 
#define DIO_BIT1_PHAFLG         (0x0001) 

#define DIO_BIT2_HFLG           (0x0004) 
#define DIO_BIT2_LFLG           (0x0002) 
#define DIO_BIT2_LUMON          (0x0001) 

#define dio_rsm()               (PORTT &= ~ DIO_RSM , PORTT |= DIO_RSM)
#define dio_busy()              (! dio_done())

int            dio_done(void);
void           dio_go(unsigned short timeout);
unsigned short dio_opid_set(unsigned short timeout, unsigned short opid, unsigned short   data);
unsigned short dio_opid_get(unsigned short timeout, unsigned short opid, unsigned short * data);

#endif

unsigned short send_packet(unsigned short timeout, unsigned short * packet);

unsigned short set_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short   data);
unsigned short get_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short * data);

unsigned short set_cdf_bits(unsigned short timeout, unsigned short   data, unsigned short mask);
unsigned short get_cdf_bits(unsigned short timeout, unsigned short * data);

unsigned short get_ffo_data_count(unsigned short timeout, unsigned short * data);
unsigned short get_ffo_lost_count(unsigned short timeout, unsigned short * data);

unsigned short set_ffo_reset(unsigned short timeout);

#endif
