// que.h  mkv  3-may-98

#ifndef QUE_H
#define QUE_H

#define QUE_FULL      (1)
#define QUE_EMPTY     (1)
#define QUE_SUCCESS   (0)
#define QUE_ERR_SIZE  (-1)
#define QUE_ERR_ALLOC (-2)

typedef void WAKEUP(void);

typedef struct
{
  unsigned short size;
  unsigned short mask;
  unsigned short head;
  unsigned short tail;
  unsigned short geti;
  unsigned short puti;
  WAKEUP *       wake;
  unsigned short data[1];
} QUEUE;

int  que_ctor(QUEUE ** qpp, unsigned short size);
void que_dtor(QUEUE * qp);
int  que_put(QUEUE * qp, unsigned short data);
int  que_get(QUEUE * qp, unsigned short * datap);
int  que_insert(QUEUE * qp, unsigned short data);
int  que_remove(QUEUE * qp, unsigned short * datap);
int  que_insert_array(QUEUE * qp, unsigned short * datap);
int  que_remove_array(QUEUE * qp, unsigned short * datap, int size);
void que_put_commit(QUEUE * qp);

#define que_isempty(qp)       ((qp)->geti == (qp)->tail)
#define que_isfull(qp)        ((qp)->head + (qp)->size == (qp)->puti)
//efine que_put_commit(qp)    {(qp)->tail = (qp)->puti; que_wakeup(qp); }
#define que_put_reset(qp)     ((qp)->puti = (qp)->tail)
#define que_get_commit(qp)    ((qp)->head = (qp)->geti)
#define que_get_reset(qp)     ((qp)->geti = (qp)->head)


#define que_put_rollback      que_put_reset
#define que_get_rollback      que_get_reset

#define que_peek(qp)          ((qp)->data[((qp)->head) & ((qp)->mask)])
#define que_headroom(qp)      ((qp)->size - ((qp)->puti - (qp)->head))
#define que_count(qp)         ((qp)->tail - (qp)->geti)
#define que_set_wakeup(qp,f)  ((qp)->wake = f)
#define que_wakeup(qp)        { if ((qp)->wake) (qp)->wake(); }

#endif
