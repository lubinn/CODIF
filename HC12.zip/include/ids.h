//  ids.h  mkv  30-jul-98

//  mkv  14-aug-98  added HKP and RAT
//  mkv  17-aug-98  added IMM
//  mkv  31-aug-98  added OP_MASK thru OP_GET
//  mkv  02-oct-98  added POL


#ifndef IDS_H
#define IDS_H


//  packet operation 
#define OP_MASK           (0x3FFF)
#define OP_DATA           (0x0000)
#define OP_REPLY          (0X4000)
#define OP_RESPONSE       (0x4000)
#define OP_SET            (0x8000)
#define OP_GET            (0xC000)


//  packet identification 

#define ID_RAT_BASE       (0x01D0)    // codif rates   
#define ID_RAT_MASK       (0X3FF0)
#define ID_RAT_SUBOP      (0X000F)

#define ID_PWR_BASE       (0X01E0)    // gse housekeeping
#define ID_PWR_MASK       (0X3FF0)
#define ID_PWR_SUBOP      (0X000F)

#define ID_CDF_BASE       (0X01F0)    // codif control, status, registers
#define ID_CDF_MASK       (0X3FFC)
#define ID_CDF_SUBOP      (0X0003)

#define ID_IMM_BASE       (0X01F4)    // codif immediate (pha) data
#define ID_IMM_MASK       (0X3FFC)
#define ID_IMM_SUBOP      (0X0003)

#define ID_HKP_BASE       (0x01F8)    // codif housekeeping
#define ID_HKP_MASK       (0X3FFC)
#define ID_HKP_SUBOP      (0X0003)

#define ID_POL_BASE       (0x01FC)    // codif poll
#define ID_POL_MASK       (0X3FFC)
#define ID_POL_SUBOP      (0X0003)



#endif

