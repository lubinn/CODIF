//  output.h  mkv  25-jul-98

//  21-sep-98  mkv  added display_output

#ifndef OUTPUT_H
#define OUTPUT_H

#include "que.h"

extern const char * output_version;

extern int display_output;

void output(QUEUE * q_src);


#endif
