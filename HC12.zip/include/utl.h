//  utl.h  mkv  25-jul-98

#ifndef UTL_H
#define UTL_H

// bit sets and clears -----------------------------------------------------
#define BIT_GET(r,b) ((r) &    (b))
#define BIT_SET(r,b) ((r) |=   (b))
#define BIT_CLR(r,b) ((r) &= ~ (b))
#define BIT_TOG(r,b) ((r) ^=   (b))


// standard types ----------------------------------------------------------
typedef unsigned char  u8;
typedef unsigned short u16;
typedef unsigned long  u32;


// isr related -------------------------------------------------------------
#define SET_VECTOR(v,isr) (* (ISR **)(v) = isr)

typedef void ISR(void);


// formatted character output ----------------------------------------------
#define putnl() putchar('\n')

void putu(u16 u, u16 radix, int width);


// globals -----------------------------------------------------------------
extern const char * version;
extern int log;
extern int stop;


// checksum accumulation ---------------------------------------------------
#ifndef UTL_C
unsigned short add_to_checksum(unsigned short * checksum, unsigned short addend);
#else
void           add_to_checksum(unsigned short * checksum, unsigned short addend);
#endif


#endif
