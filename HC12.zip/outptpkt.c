//  outptpkt.c  mkv  19-aug-98

//  19-aug-98  mkv  created from outputmv.c and outputtf.c with changes
//  21-sep-98  mkv  added display_output, modified handshaking
//  30-sep-98  mkv  removed timeout2 tell-tale

#include <output.h>
#include <utl.h>
#include <dio.h>

#include <stdio.h>

int display_output = 0;

#ifdef MKV_IO  // mv version --------------------------------------------------------------

const char * output_version = __FILE__ " " __DATE__ " " __TIME__ " mv\n";

static void output_word(unsigned short timeout, unsigned short data)
{
  unsigned short timeout2 = timeout;
  unsigned short timeout3 = 100;

  while (--timeout2 && ! dio_write_ready())
  {
  }
/*
	if (timeout2 == 0)
		putchar('-');
*/
  dio_write_word(data);

  dio_write_request();

  while (--timeout3)
  {
  }

  dio_write_acknowledge();
}  

void output(QUEUE * q_src)
{
  dio_write_acknowledge();

  if (! que_isempty(q_src))
  {
    unsigned short csum = 0;
    unsigned short n    = que_get(q_src, 0);

		if (display_output)
		{
    	puts("\no: "); putu(n, 16, 4);
		}

    while (n--)
    {
      unsigned short data = que_get(q_src, 0);

      add_to_checksum(& csum, data);

      output_word(0, data);

			if (display_output)
			{
      	putchar(' '); putu(data, 16, 4);
			}
    }

    output_word(0, csum);

		if (display_output)
		{
    	putchar(' '); putu(csum, 16, 4);
		}

    que_get_commit(q_src);
  }  
}  

#else  // tf version ----------------------------------------------------------------------

const char * output_version = __FILE__ " " __DATE__ " " __TIME__ " tf\n";

void output(QUEUE * q_src)
{
  if (! que_isempty(q_src) && dio_done())
  {
    unsigned short * p = & DIO_PKT_ZERO;
    unsigned short   n = que_get(q_src, 0);

    puts("\no: "); putu(n, 16, 4);

    while (n--)
    {
      unsigned short data = que_get(q_src, 0);

      * p++ = data;

      putchar(' '); putu(data, 16, 4);
    }

    dio_go(0);

    que_get_commit(q_src);
  }
}  

#endif
