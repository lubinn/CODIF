//  procdfpo.c  mkv  02-oct-98

#include <dio.h>
#include <process.h>

#define CDF_POLL_NEW_DATA   (0x8000)


int process_cdf_poll(unsigned short * packet)
{
  if ((packet[PKT_OPID] & ID_POL_MASK) != ID_POL_BASE)
    return 0;

  if (packet[PKT_WCNT] == 2)
  {
    unsigned short reg;

    switch(packet[PKT_OPID] & ID_POL_SUBOP)
    {
      case 0:
        reg = CDF_REG_LS_PHA_TOF;
        break;

      case 1:
        reg = CDF_REG_HS_PHA_TOF;
        break;

      default:
        packet[PKT_WCNT] = 0;    
        return 1;
        break;
    }

    //  get the poll data, first tof, then position
    get_cdf_reg(0, reg,     & packet[PKT_DAT0]);
    get_cdf_reg(0, reg + 1, & packet[PKT_DAT1]);

    //  if valid, cleanup and report it, otherwise return empty packet
    if (packet[PKT_DAT0] & CDF_POLL_NEW_DATA)
    {
      packet[PKT_WCNT]  = 4;
      packet[PKT_DAT0] &= 0x00FF;
      packet[PKT_DAT1] &= 0x03FF;
    }
  }
  else
    packet[PKT_WCNT] = 0;    

  return 1;
}  
