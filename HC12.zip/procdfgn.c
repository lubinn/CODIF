//  procdfgn.c  mkv  17-aug-98

//  mkv  19-aug-98  added tf i/o
//  mkv  23-aug-98  changed packet formats
//  mkv  30-sep-98  masked off upper eight bits of eight bit registers
//  mkv  28-oct-98  altered logic of tf CDF_BIT_RESET and get_cdf_bits
//  mkv  01-nov-98  added pac and mcp dac shadowing

#include <process.h>

static unsigned short shadow_pac_dac = 0;
static unsigned short shadow_mcp_dac = 0;

#ifdef MKV_IO  //--------------------------------------------------------------------------

unsigned short set_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short   data)
{
  CDF_DAT  = data;
  CDF_CTL  = (CDF_CTL & ~ CDF_CTL_REG_MASK) | (reg & CDF_CTL_REG_MASK);
  CDF_STS |=   CDF_STS_WRITE;
  CDF_STS &= ~ CDF_STS_WRITE;

  return 1;
}  

unsigned short get_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short * data)
{
  CDF_CTL  = (CDF_CTL & ~ CDF_CTL_REG_MASK) | (reg & CDF_CTL_REG_MASK);
  CDF_STS |=   CDF_STS_READ;
  CDF_STS &= ~ CDF_STS_READ;
  * data   = CDF_DAT;

  //  registers >= 16 are 8 bit registers
  if (reg >= 16)
    * data &= 0xFF;

  return 1;
}


/* routines to map bits to from standard (sw) to special (hw) positions

  standard (sw)     bit   special (hw)

  ^                  15   CDF_CSR_HFLG    
  |                  14   CDF_CSR_LFLG    
  |                  13   CDF_CSR_STANDBY 
  | unused           12   CDF_CSR_LUMON   
  |                  11   CDF_CSR_READ    
  |                  10   CDF_CSR_WRITE   
  v                  9    CDF_CSR_CNTSMP  
  CDF_BIT_CNTSMP     8    CDF_CSR_RESET   
  CDF_BIT_HFLG       7    CDF_CSR_PWCTLH  
  CDF_BIT_LFLG       6    CDF_CSR_PWCTLL  
  CDF_BIT_LUMON      5    CDF_CSR_PHAFLG  
  CDF_BIT_STANDBY    4    ^
  CDF_BIT_RESET      3    |
  CDF_BIT_PWCTLH     2    | codif register number
  CDF_BIT_PWCTLL     1    |
  CDF_BIT_PHAFLG     0    v
 */

static unsigned short unpack_bits(unsigned data)
{
  unsigned short temp;

  // set in the cntsmp bit
  data <<= 1;
  temp   = data & CDF_CSR_CNTSMP;

  // set in the reset, pwclth, pwctll, and phaflg bits
  data <<= 4;
  temp  |= data & (CDF_CSR_RESET | CDF_CSR_PWCTLH | CDF_CSR_PWCTLL | CDF_CSR_PHAFLG);

  // set in the lumon bit
  data <<= 2;
  temp  |= data & CDF_CSR_LUMON;

  // set in the hflg and lflg bits
  data <<= 1;
  temp  |= data & (CDF_CSR_HFLG | CDF_CSR_LFLG);

  // set in the standby bit
  data <<= 1;
  temp  |= data & CDF_CSR_STANDBY;

  return temp;
}   

static unsigned short pack_bits(unsigned data)
{
  unsigned short temp;

  // set in the cntsmp bit
  data >>= 1;
  temp   = data & CDF_BIT_CNTSMP;

  // set in the reset, pwclth, pwctll, and phaflg bits
  data >>= 4;
  temp  |= data & (CDF_BIT_RESET | CDF_BIT_PWCTLH | CDF_BIT_PWCTLL | CDF_BIT_PHAFLG);

  // set in the lumon bit
  data >>= 2;
  temp  |= data & CDF_BIT_LUMON;

  // set in the hflg and lflg bits
  data >>= 1;
  temp  |= data & (CDF_BIT_HFLG | CDF_BIT_LFLG);

  // set in the standby bit
  data >>= 1;
  temp  |= data & CDF_BIT_STANDBY;

  return temp;
}   

unsigned short set_cdf_bits(unsigned short timeout, unsigned short   data, unsigned short mask)
{
  // map data and mask bits from standard to special positions
  data = unpack_bits(data);
  mask = unpack_bits(mask);

  // change the selected bits
  CDF_CSR  = (CDF_CSR & ~ mask) | (data & mask);

  // reset the "pulse" bits in case they were set
  CDF_CSR &= ~ (CDF_CSR_READ | CDF_CSR_WRITE | CDF_CSR_CNTSMP | CDF_CSR_RESET);

  return 1;
}

unsigned short get_cdf_bits(unsigned short timeout, unsigned short * data)
{
  // map data bits from special to standard positions
  * data = pack_bits(CDF_CSR);
  
  return 1;  
}

#else  //----------------------------------------------------------------------------------

unsigned short dio_opid_set(unsigned short timeout, unsigned short opid, unsigned short   data)
{
  while (dio_busy())
  {
  }

  DIO_PKT_DATA = data;
  DIO_PKT_OPID = DIO_OP_SET | opid;

  dio_go(timeout);

  while (dio_busy())
  {
  }

  return 1;
}

unsigned short dio_opid_get(unsigned short timeout, unsigned short opid, unsigned short * data)
{
  while (dio_busy())
  {
  }

  DIO_PKT_OPID = DIO_OP_GET | opid;

  dio_go(timeout);

  while (dio_busy())
  {
  }

  * data = DIO_PKT_DATA;

  return 1;
}

unsigned short set_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short   data)
{
  return dio_opid_set(0, DIO_DEV_CDF_REG | (reg & 0x00ff), data);
}  

unsigned short get_cdf_reg(unsigned short timeout, unsigned short reg, unsigned short * data)
{
  unsigned reply = dio_opid_get(0, DIO_DEV_CDF_REG | (reg & 0x00ff), data);

  //  registers >= 16 are 8 bit registers
  if (reg >= 16)
    * data &= 0xFF;

  return reply;
}  

unsigned short set_cdf_bits(unsigned short timeout, unsigned short data, unsigned short mask)
{
  unsigned short resetting = data & mask & CDF_BIT_RESET;
  unsigned short temp;

  //  convert high true reset to low true, clear unused bits
  data ^= CDF_BIT_RESET;
  data &= mask;

  //  cntsmp is a special case, handle it and reset the data bit
  if (data & CDF_BIT_CNTSMP)
  {
    dio_opid_set(0, DIO_DEV_CDF_CNTSMP, 0);
    data ^= CDF_BIT_CNTSMP;
  }

  // get the current state of the bits
  dio_opid_get(0, DIO_DEV_CDF_BITS_1, & temp);

  // clear and set the bits to be changed
  temp &= ~ mask;
  temp |= data;
  
  // restore the new values
  dio_opid_set(0, DIO_DEV_CDF_BITS_1, temp);

  // if the reset was selected, set it to clear the reset
  if (resetting)
    dio_opid_set(0, DIO_DEV_CDF_BITS_1, temp | CDF_BIT_RESET);

  return 1;
} 
 
unsigned short get_cdf_bits(unsigned short timeout, unsigned short * data)
{
  unsigned short bits1, bits2;

  // get the first set of bits
  dio_opid_get(0, DIO_DEV_CDF_BITS_1, & bits1);

  // clear any noise in bits1
  bits1 &= 0x001F;

  // and get the second set of bits
  dio_opid_get(0, DIO_DEV_CDF_BITS_2, & bits2);

  // clear any noise in bits2
  bits2 &= 0x0007;

  // combine bits1 and bits2, complementing the low true reset to high true
  * data = ((bits2 << 5) | bits1) ^ CDF_BIT_RESET;

  return 1;
}  

#endif  //---------------------------------------------------------------------------------
 

int process_cdf_general(unsigned short * packet)
{
  int reply = 0;

  if ((packet[PKT_OPID] & ID_CDF_MASK) != ID_CDF_BASE)
    return 0;

  {
    unsigned short wcnt  = packet[PKT_WCNT];
    unsigned short dat0  = packet[PKT_DAT0];
    unsigned short dat1  = packet[PKT_DAT1];
    
    switch (packet[PKT_OPID] & ID_CDF_SUBOP)
    {
      case 0:     // generic data read/write and reply, reg in dat0, data in dat1
        switch (wcnt)
        {
          // write to register then read
          case 4: set_cdf_reg(0, dat0,   dat1);

                  // shadow mcp dac
                  if (dat0 == 29)
                    shadow_mcp_dac = dat1;

                  // shadow pac dac
                  if (dat0 == 30)
                    shadow_pac_dac = dat1;

          // read from register
          case 3: get_cdf_reg(0, dat0, & dat1);

                  // shadow mcp dac
                  if (dat0 == 29)
                    dat1 = shadow_mcp_dac;

                  // shadow pac dac
                  if (dat0 == 30)
                    dat1 = shadow_pac_dac;

						      // reply with register and value 
						      packet[PKT_WCNT]  = 4;
						      packet[PKT_DAT1]  = dat1;

                  reply = 1;
        }
        break;

      case 1:     // selectivly set bits in control status register
        switch (wcnt)
        {
          // mask is in DAT0 lsb, data is in DAT0 msb
          case 3: dat1  = dat0 >> 8;
                  dat0 &= 0x00ff;

          // mask is in DAT0, data is in DAT1
          case 4: set_cdf_bits(0, dat1, dat0);

          // just asking, get the bits
          case 2: get_cdf_bits(0, & dat0);

						      // reply with codif status
						      packet[PKT_WCNT]  = 3;

                  reply = 1;
        }
				break;
    }

    if (reply) 
      packet[PKT_DAT0]  = dat0;
    else
 		  packet[PKT_WCNT]  = 0;    
  }

  return 1;
}  
