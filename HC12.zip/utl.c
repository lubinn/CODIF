//  utl.c  mkv  25-jul-98

#define UTL_C

#include <utl.h>

#include <stdio.h>

// global flags ------------------------------------------------------------
int stop = 0;
int log  = 0;


//  versions of getchar and putchar using sci and osYield ------------------          
/*
int getchar(void)
{
  unsigned char ch;

  while (sci_get(&ch))
    osYield();

  return ch;
}  

int putchar(char ch)
{
  if (ch == '\n')
    putchar('\r');

  while (sci_put(ch))
    osYield();

  return ch;
} 
*/

// version of puts that doesn't add \n at end of string --------------------
int puts(const char * s)
{
  int n = 0;

  while (*s)
  {
    putchar(*s++);
    ++n;    
  }

  return n;
}  

//  putu -------------------------------------------------------------------
static char xtoa[] = "0123456789ABCDEF";

static void putu2(u16 u, u16 radix, int width)
{
  if (u == 0 && width <= 0)
  {
    // do nothing
  }
  else if (u == 0 && width > 0)
  {
    putu2(0, radix, width - 1);
    putchar( radix == 10 ? ' ' : '0' );
  }
  else
  {
    putu2(u / radix, radix, width - 1);
    putchar(xtoa[u % radix]);
  }
}  

void putu(u16 u, u16 radix, int width)
{
  if (u >= radix || width > 1)
    putu2(u / radix, radix, width - 1);

  putchar(xtoa[u % radix]);
}


// checksum accumulation ---------------------------------------------------
void add_to_checksum(unsigned short * checksum, unsigned short addend)
{
/**/
  union
  {
    unsigned long  ul;
    unsigned short us[2];
  } temp;
  
  temp.ul = (unsigned long) * checksum + addend;
    
  *checksum = temp.us[0] + temp.us[1];
/**/
/*
  // *checksum is in D, addend is on the stack

  asm("tfr  d,y");       // put *checksum in index register Y
  asm("ldd  0,y");       // load checksum into D
  asm("addd 2,sp");      // add addend to D
  asm("adcb #0");        // add carry to lsb of D
  asm("adca #0");        // add carry to msb of D
  asm("std  0,y");       // replace checksum with new sum
*/
}  

// faster memcpy -----------------------------------------------------------
void * memcpy(void * dst, void * src, unsigned int count)
{
	asm("     pshd"         );  // save dst
	asm("     pshx"         );  // save X

  //  count -> 8,sp
  //    src -> 6,sp
  //     pc -> 4,sp
  //    dst -> 2,sp
  //  old x -> 0,sp  
  //    dst -> D

  asm("     tfr   d,y"      );  // dst in Y
  asm("     ldx   6,sp"     );  // src in X
  asm("     ldd   8,sp"     );  // count in d

  asm("     lsrd"           );  // convert to word count, odd byte to C
  asm("     bcc   v01"      );  // no odd byte, treat as word copy

  asm("     movb  1,x+,1,y+");  // move the odd byte
  asm("v01: beq  v03"       );  // exit if word count == 0

  asm("v02: movw  2,x+,2,y+");  // move a word
  asm("     dbne  d,v02"    );  // decrement count, repeat of not zero

//  return dst;
	asm("v03: pulx"           );  // restore X
	asm("     puld"           );  // return dst
}  
