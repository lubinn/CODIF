//  dioecho.c  mkv  25-jul-98

//  21-sep-98  mkv  added command processor


#include <config.h>
#include <dio.h>
#include <que.h>
#include <utl.h>

#include <input.h>
#include <process.h>
#include <output.h>

#include <hc12.h>
#include <stdio.h>

#define RDRF    (0x20)
#define kbhit() (SC0SR1&RDRF)

void command(void)
{
	if(kbhit())
	{
		char c = getchar();

		switch(c)
		{
			case 'i':
				display_input  ^= 1;
				puts("\ninput "); 
				puts( display_input ? "on" : "off" );
				break;

			case 'o':
				display_output ^= 1;
				puts("\noutput "); 
				puts( display_output ? "on" : "off" );
				break;
		}
	}
}

void main(void)
{
  set_configuration();

  puts(input_version);
  puts(process_version);
  puts(output_version);

  {
    QUEUE * q_input;
    QUEUE * q_output;

    que_ctor(& q_input,  512);
    que_ctor(& q_output, 512);

    while(1)
    {
			command();
      input(q_input);
      process(q_output, q_input);
      output(q_output);
    } 
  }
}  




  

