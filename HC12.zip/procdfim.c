//  procdfim.c  mkv  17-aug-98

//  15-sep-98  mkv  removed reference to ID_REPLY
//  18-sep-98  mkv  conditionalized om MKV_IO
//  07-oct-98  mkv  added fifo reset
//  08-oct-98  mkv  modified the fifo read code


#include <process.h>

#define MAX_REPLY_WCNT (250)


int process_cdf_immediate(unsigned short * packet)
{
  int reply = 0;

  if ((packet[PKT_OPID] & ID_IMM_MASK) != ID_IMM_BASE)
    return 0;

  {
    unsigned wcnt       = packet[PKT_WCNT];
    unsigned reply_wcnt = packet[PKT_DAT0];

    switch (packet[PKT_OPID] & ID_IMM_SUBOP)
    {
      case 0: // read immediate data
        switch (wcnt)
        {
          case 2:
            // setup to read maximum count, if possible
            reply_wcnt = MAX_REPLY_WCNT;

          case 3:
            // use supplied reply word count, if legal
						if (reply_wcnt == 0 || reply_wcnt > MAX_REPLY_WCNT)
							reply_wcnt = MAX_REPLY_WCNT;

		        reply = 1;
        }

    	  if (reply)
  	  	{
#ifdef MKV_IO
    	    unsigned short * ptr = & packet[PKT_DAT0];

    	    packet[PKT_WCNT]  = 2;

    	    // fill the requet with as much data as we have lying around
          while (!(FFO_STS & FFO_STS_EMPTY) && reply_wcnt-- )
          {
    				// get a fifo word
    				FFO_CTL |=   FFO_CTL_READ;

    				// put it in the packet
            * ptr++ = FFO_DAT;

            // cancel the fifo read
    				FFO_CTL &= ~ FFO_CTL_READ;

    				// bump the packet word count
    				++packet[PKT_WCNT];
          }        

#else
          // add tf code here, change following line
          packet[PKT_WCNT] = 0;
#endif

    		}
    	  else
    	    packet[PKT_WCNT] = 0;    
        break;


      case 1: // reset fifos
        switch(wcnt)
        {
          case 2:
#ifdef MKV_IO
            FFO_CTL |=   FFO_CTL_RESET;
            FFO_CTL &= ~ FFO_CTL_RESET;
#else
            // add tf code here, change following line
            packet[PKT_WCNT] = 0;
#endif
            break;
        }
        break;
    }
  }

  return 1;
}  
