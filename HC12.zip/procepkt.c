//  procepkt.c  mkv  26-jul-98

//  mkv  29-jul-98  added wordcount to checksum
//  mkv  14-aug-98  added housekeeping commands
//  mkv  17-aug-98  broke into seperate source files
//  mkv  22-aug-98  removed checksum calculation
//  mkv  23-aug-98  incremented packet[PKT_WCNT] during output
//  mkv  31-aug-98  tagged response packets with ID_RESPONSE
//  mkv  13-sep-98  added immediate processing
//  mkv  02-oct-98  added poll processing


#include <process.h>

#include <stdio.h>
#include <hc12.h>

#include <utl.h>
#include <dio.h>
#include <ids.h>


const char * process_version = __FILE__ " " __DATE__ " " __TIME__ "\n";


int process_echo(unsigned short * packet)
{
  return 1;  
} 
 
processor * processors[] = 
{
  process_pwr_general,
  process_cdf_general,
  process_cdf_immediate,
  process_cdf_housekeeping,
  process_cdf_rates,
  process_cdf_poll,
  process_echo,					// must be last before the null
  0  
};


//------------------------------------------------------------------------------------
static unsigned short packet_count 		    = 0;
static unsigned short process_flag        = QUE_SUCCESS;
static unsigned short process_packet[300] = { 0 };


void process(QUEUE * q_dst, QUEUE * q_src)
{
  if (process_flag != QUE_SUCCESS)
    process_flag = que_insert_array(q_dst, process_packet);
  else
  if (! que_isempty(q_src))
  {
    // get the input packet
    {
      unsigned short   n = que_get(q_src, 0);
      unsigned short * p = & process_packet[PKT_WCNT];

      *p++ = n;

      while (n--)
        * p++ = que_get(q_src, 0);

      que_get_commit(q_src);
    }

    // process the packet
    {
      processor * * p = processors;

      while (*p && ! (*p)(process_packet))
        p++;

      // exit if nobody processed the packet or no reply
      if (*p == 0 || process_packet[PKT_WCNT] == 0)
      {
        process_flag = QUE_SUCCESS;
        return;
      }
    }

    // put the response packet
    process_packet[PKT_LENG]  = process_packet[PKT_WCNT] + 2;
    process_packet[PKT_ZERO]  = 0;
	  process_packet[PKT_WCNT] += 1;
    process_packet[PKT_OPID] &= OP_MASK;
    process_packet[PKT_OPID] |= OP_REPLY;

    process_flag = que_insert_array(q_dst, process_packet);
  }
} 
