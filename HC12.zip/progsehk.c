//  progsehk.c  mkv  17-aug-98

//  mkv  23-aug-98  converted to 8-bit values, packed 8 to a packet
//  mkv  26-aug-98  inverted low three mux selection bits


#include <process.h>


//------------------------------------------------------------------------------------
// convert a single channel four times
static void pwr_ad_convert(unsigned short channel, unsigned char * value)
{
  unsigned short timeout = 0;

  // set channel and start conversion
  ATDCTL5 = (CB | CA) & channel;

  // spin until done
  while ((ATDSTAT & SCF) == 0 && --timeout)
  {
  }

  if (timeout)  
  {
		unsigned short value_x4;

    // sum the four samples taken of the channel
    value_x4  = ADR0H;
    value_x4 += ADR1H;
    value_x4 += ADR2H;
    value_x4 += ADR3H;

    // average them
    * value = (value_x4 + 2) >> 2;
  }
}  

// convert channel in range 0 to 18 - first 16 are multiplexed on channel 0, final 3 on channels 1 to 3
static void pwr_measure(unsigned short channel, unsigned char * value)
{
  if (channel < 16)
  {
    PORTG = PORTG & (~ PWR_MUX) | (channel ^ 0x07);
    pwr_ad_convert(PWR_HK0, value);      
  }
  else
  if (channel < 19)
    pwr_ad_convert(PWR_T1 + channel - 16, value);
  else
	  // return value of 0 for bad channel or timeout
    * value = 0;      
}

// this code was in the place of the call but the compiler couldn't handle it
static void pwr_compiler_bug(unsigned short begin, unsigned short end, unsigned char * value)
{
  while (begin <= end)
    pwr_measure(begin++, value++);
}  

// process power system packets 
int process_pwr_general(unsigned short * packet)
{
  int reply = 0;

  if ((packet[PKT_OPID] & ID_PWR_MASK) != ID_PWR_BASE)
    return 0;

  {
    unsigned wcnt  = packet[PKT_WCNT];
		unsigned opid  = packet[PKT_OPID] & ID_PWR_SUBOP;
    unsigned begin = packet[PKT_DAT0];
    unsigned end	 = packet[PKT_DAT1];
  
    if (opid < 3)
    {
			// case 0: channels  0 -  7
			// case 1: channels  8 - 15
			// case 2: channels 16 - 18
      if (wcnt == 2)
      {
        // setup to read all values in range
				if (opid < 2)
				{
          packet[PKT_WCNT] = 6;

          begin = opid << 3;
          end   = begin + 7;
				}
				else
				{
          packet[PKT_WCNT] = 4;

          begin = 16;
          end   = 19;		  // zero fills the extra byte
				}

        // fill the packet
        pwr_compiler_bug(begin, end, (unsigned char *) & packet[PKT_DAT0]);

        reply = 1;
      }
		}
		else
		{
      // case 3: power on and off
      switch (wcnt)
      {
        case 3:
          // set/reset the selected bits, mask is in begin (DAT0) lsb, data is in begin (DAT0) msb
          end = begin >> 8;

        case 4:
          // set/reset the selected bits, mask is in begin (DAT0), data is in end (DAT1)
          PORTG = (PORTG & ~ begin) | (end & begin);

        case 2:
          // return power bit status
          packet[PKT_WCNT] = 3;
          packet[PKT_DAT0] = PORTG;

          reply = 1;
      }
    }
  }  

  if (! reply)
    packet[PKT_WCNT]  = 0;    

  return 1;
}  


