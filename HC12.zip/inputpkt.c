//  inputpkt.c  mkv  27-jul-98

//  29-jul-98  mkv  added wordcount to checksum
//  21-sep-98  mkv  added display_input

#include <input.h>
#include <que.h>
#include <utl.h>
#include <dio.h>

#include <hc12.h>
#include <stdio.h>



static void input_sync(QUEUE * q_dst);
static void input_sync_2(QUEUE * q_dst);
static void input_word_count(QUEUE * q_dst);
static void input_body(QUEUE * q_dst);
static void input_csum(QUEUE * q_dst);
static void input_enque(QUEUE * q_dst);


const char * input_version = __FILE__ " " __DATE__ " " __TIME__ "\n";

void (*input)(QUEUE *) = input_sync;

int display_input = 0;


static unsigned short   input_timeout    = 1000;
static int              input_ready      = 0;
static unsigned short * input_data       = 0;
static unsigned short   input_packet[16] = { 0 };
static unsigned short   input_checksum   = 0;
static unsigned short   saved_checksum   = 0;


static void input_get(void)
{
  dio_read_request();

  input_ready = dio_read_ready();

  if (input_ready)
  {
    unsigned short timeout;

    * input_data = dio_read_word();

    dio_read_acknowledge();

    // do not move the following, it creates a delay between the fall and rise of read request
//  timeout = input_timeout; while (--timeout) {}

    add_to_checksum(& input_checksum, * input_data);

    dio_read_request();

    timeout = input_timeout; while (--timeout && dio_read_ready()) {}

		if (display_input)
		{
	    putchar(' '); putu(* input_data, 16, 4);
		}

    ++input_data;
  }
} 
 

static void input_sync(QUEUE * q_dst)
{
	if (display_input)
	{
  	puts("\ni:"); 
	}

  input = input_sync_2;
  input(q_dst);
} 


static void input_sync_2(QUEUE * q_dst)
{
  input_data = input_packet;  

  input_get();

  if (input_ready && input_packet[0] == 0)
    input = input_word_count;
}  


static void input_word_count(QUEUE * q_dst)
{
  input_data     = input_packet + 1;
  input_checksum = 0;

  input_get();

  if (input_ready)
    if (3 <= input_packet[1] && input_packet[1] <= 7)
      input = input_body;
    else
    if (input_packet[1] != 0)
      input = input_sync;
} 

static void input_body(QUEUE * q_dst)
{
  input_get();

  if (input_ready)
  {
    if (input_data - input_packet == input_packet[1] + 1)
    {
      saved_checksum = input_checksum;
      input_checksum = 0;

      input = input_csum;
    }
  } 
}

static void input_csum(QUEUE * q_dst)
{
  input_get();

  if (input_ready)
  {
    if (input_checksum == saved_checksum)
    {
      --input_packet[1];
      
      input = input_enque;
    }
    else
    {
			if (display_input)
			{
	      puts("\ns: "); putu(saved_checksum, 16, 4); puts("!="); putu(input_checksum, 16, 4);
			}

      input = input_sync;
    }
  }
}

static void input_enque(QUEUE * q_dst)
{
  if (que_insert_array(q_dst, & input_packet[1]) == QUE_SUCCESS)
    input = input_sync;
}     
