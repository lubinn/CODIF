//  que.c  mkv  3-may-98

#include <stdlib.h>
#include <que.h>

int que_ctor(QUEUE ** qpp, unsigned short size)
{
  QUEUE * qp;

  // size must be a power of two
  if (size & (~size + 1) != size)
    return QUE_ERR_SIZE;
   
  if ((qp = (QUEUE *) malloc( sizeof(QUEUE) + sizeof(unsigned short) * (size - 1) )) == 0)
    return QUE_ERR_SIZE;

  qp->size = size;
  qp->mask = size-1;
  qp->head = 0;
  qp->tail = 0;
  qp->geti = 0;
  qp->puti = 0;
  qp->wake = 0;

  *qpp = qp;
  return QUE_SUCCESS;
} 
 
void que_dtor(QUEUE * qp)
{
  free(qp);
}  

int  que_put(QUEUE * qp, unsigned short data) 
{
  if (que_isfull(qp))
    return QUE_FULL;

  qp->data[qp->mask & qp->puti++] = data;
//que_put_commit(qp);
  return QUE_SUCCESS;
}

int  que_get(QUEUE * qp, unsigned short * datap)
{
  unsigned short result = QUE_EMPTY;

  if (! que_isempty(qp))
  {
    result = qp->data[qp->mask & qp->geti++];
//  que_get_commit(qp);

    if (datap)
    {
      *datap = result;
      result = QUE_SUCCESS;
    }
  }
    
  return result;
}

int  que_insert(QUEUE * qp, unsigned short data)
{
  int result = que_put(qp, data);

  if (result == QUE_SUCCESS)
    que_put_commit(qp);

  return result;
}

int  que_remove(QUEUE * qp, unsigned short * datap)
{
  unsigned short temp;
  int result = que_get(qp, & temp);

  if (result == QUE_SUCCESS)
    que_get_commit(qp);

  if (datap)
    * datap = temp;
  else
    result = temp;

  return result;
}  

int  que_insert_array(QUEUE * qp, unsigned short * datap)
{
  int wc = *datap;

  if (wc >= que_headroom(qp))
    return QUE_FULL;

  while (wc-- >= 0)
    que_put(qp, *datap++);

  que_put_commit(qp);
  return QUE_SUCCESS;  
}

int  que_remove_array(QUEUE * qp, unsigned short * datap, int size)
{
  int wc = que_peek(qp);

  if (wc >= que_count(qp))
    return QUE_EMPTY;
  
  if (wc >= size)
    return QUE_ERR_SIZE;
  
  while (wc-- >= 0)
    que_get(qp, datap++);
    
  que_get_commit(qp);
  return QUE_SUCCESS;
}

void que_put_commit(QUEUE * qp)
{
  qp->tail = qp->puti;

  if (qp->wake)
    qp->wake();
}  