//  dio.c  mkv  21-jul-98

//  mkv  20-aug-98  added tf i/o

#include <dio.h>


unsigned short dio_get(unsigned short timeout, unsigned short * data)
{
  dio_read_request();

  while (! dio_read_ready() && --timeout)
  {
    unsigned short delay = 0;

    while (! dio_read_ready() && --delay)
    {
    }
  }

  if (timeout)
    * data = dio_read_word();
    
  dio_read_acknowledge();

  return timeout;
}


#ifdef  MKV_IO

unsigned short dio_put(unsigned short timeout, unsigned short data)
{
  dio_write_word(data);

  dio_write_send();
    
  while (! dio_write_received() && --timeout)
  {
    unsigned short delay = 0;

    while (! dio_write_received() && --delay)
    {
    }
  }

  dio_write_acknowledge();

  return timeout;
}  

#else

static unsigned short dio_timeout = 0;

int dio_done(void)
{
  if ((PORTT & DIO_BUSY) == 0)
  {
    dio_timeout = 0;
    return 1;
  }

  if (--dio_timeout)
    return 0;

  dio_rsm();
  return 1;    
}  

void dio_go(unsigned short timeout)
{
  dio_rsm();

  dio_timeout = timeout;
  DIO_STS     = DIO_GO;
}

#endif

